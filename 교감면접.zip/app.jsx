const { useState, useEffect, useRef } = React;

// ---------- Data ----------
const TOPICS_44 = [
  // 교양
  { n: "01", t: "사회현상 (8주제 택1)", g: "선택형", area: "교양" },
  { n: "02", t: "존경 인물 (6인 택1)", g: "선택형", area: "교양" },
  { n: "03", t: "AI 시대 교감 역할", g: "선택형", area: "교양" },
  { n: "04", t: "교육공동체 갈등 중재", g: "공동체·갈등", area: "교양" },
  { n: "05", t: "지역사회 상생 학교 운영", g: "공동체·갈등", area: "교양" },
  { n: "06", t: "학부모 교육 참여 활성화", g: "공동체·갈등", area: "교양" },
  { n: "07", t: "악성·반복 민원 대응", g: "공동체·갈등", area: "교양" },
  { n: "08", t: "교원 복무 갈등 해결", g: "공동체·갈등", area: "교양" },
  { n: "09", t: "교원 전문성 신장 지원", g: "교원·장학", area: "교양" },
  { n: "10", t: "신규 교사 현장 안착", g: "교원·장학", area: "교양" },
  { n: "11", t: "자율장학 운영", g: "교원·장학", area: "교양" },
  { n: "12", t: "방과후학교 운영", g: "교원·장학", area: "교양" },
  { n: "13", t: "교원 업무 경감", g: "행정·운영", area: "교양" },
  { n: "14", t: "2022 개정 교육과정", g: "행정·운영", area: "교양" },
  { n: "15", t: "교육청 정책 안착", g: "행정·운영", area: "교양" },
  { n: "16", t: "AI가 교수학습·평가에 미치는 영향", g: "AI·디지털", area: "교양" },
  { n: "17", t: "디지털로 학교 운영 효율화", g: "AI·디지털", area: "교양" },
  { n: "18", t: "AI 활용 교수·학습 지원", g: "AI·디지털", area: "교양" },
  { n: "19", t: "AI 도입과 격차 해소", g: "AI·디지털", area: "교양" },
  { n: "20", t: "AI·디지털 맞춤형 학습", g: "AI·디지털", area: "교양" },
  // 교직
  { n: "21", t: "세종교육 3대 핵심과제", g: "세종 정책", area: "교직" },
  { n: "22", t: "세종미래장학", g: "세종 정책", area: "교직" },
  { n: "23", t: "교육계획집중수립주간", g: "세종 정책", area: "교직" },
  { n: "24", t: "학교평가 내실 운영", g: "세종 정책", area: "교직" },
  { n: "25", t: "학생 맞춤형 통합 지원", g: "학생지원", area: "교직" },
  { n: "26", t: "특수교육대상학생 지원", g: "학생지원", area: "교직" },
  { n: "27", t: "감염병 예방 및 관리", g: "학생지원", area: "교직" },
  { n: "28", t: "급식 사고 대처", g: "위기·안전", area: "교직" },
  { n: "29", t: "학교폭력 사안 처리", g: "위기·안전", area: "교직" },
  { n: "30", t: "아동학대 사안 처리", g: "위기·안전", area: "교직" },
  { n: "31", t: "안전한 체험학습 운영", g: "위기·안전", area: "교직" },
  { n: "32", t: "교육활동 침해 대응", g: "위기·안전", area: "교직" },
  { n: "33", t: "심리·정서 위기 학생", g: "위기·안전", area: "교직" },
  { n: "34", t: "계약제 교원 채용·관리", g: "인사·복무", area: "교직" },
  { n: "35", t: "교사 다면평가", g: "인사·복무", area: "교직" },
  { n: "36", t: "교원 휴직", g: "인사·복무", area: "교직" },
  { n: "37", t: "교원 휴가", g: "인사·복무", area: "교직" },
  { n: "38", t: "교원 겸직 허가", g: "인사·복무", area: "교직" },
  { n: "39", t: "미디어리터러시 교육", g: "교육 혁신", area: "교직" },
  { n: "40", t: "독서인문교육", g: "교육 혁신", area: "교직" },
  { n: "41", t: "문해력 교육", g: "교육 혁신", area: "교직" },
  { n: "42", t: "기초학력 부진 학생 지원", g: "교육 혁신", area: "교직" },
  { n: "43", t: "디지털 역량 기반 수업", g: "교육 혁신", area: "교직" },
  { n: "44", t: "학교자율시간 운영", g: "교육 혁신", area: "교직" },
];

const STEPS = [
  {
    n: "I", k: "전체 지도 그룹화", sub: "Map",
    body: "교양(01–20)·교직(21–44) 영역의 전체 지도로 주제별 그룹을 머릿속에 그립니다. 그룹의 위치를 알면 어떤 문항이 나와도 길을 잃지 않습니다.",
    chips: ["선택형", "공동체·갈등", "AI·디지털", "위기·안전", "세종 정책", "교육 혁신"],
  },
  {
    n: "II", k: "핵심 3키워드 숙지", sub: "Anchor",
    body: "각 문항의 답변을 구성하는 뼈대 — 세 개의 핵심 키워드를 외웁니다. 키워드가 답변의 좌표가 됩니다.",
    chips: ["전문학습공동체", "맞춤형 연수", "세종미래장학"],
  },
  {
    n: "III", k: "답변 흐름 연결", sub: "Flow",
    body: "‘첫째·둘째·셋째’로 이어지는 실전 답변의 흐름을 순서대로 연결합니다. 키워드가 흐름이 되는 순간 외운 것이 ‘말’이 됩니다.",
    chips: ["첫째 — 예방·기획", "둘째 — 운영·실행", "셋째 — 지원·환류"],
  },
  {
    n: "IV", k: "혼동 주의 표 활용", sub: "Distinguish",
    body: "비슷해 보이는 주제의 미세한 차이를 구별합니다. 07 악성·반복 민원은 ‘창구 일원화’, 32 교육활동 침해는 ‘교육활동보호위원회 가동’ — 한 단어가 합격선을 가릅니다.",
    chips: ["07 ↔ 32", "09·10·11", "16–20", "28–33", "36·37·38"],
  },
];

const VALUES_3 = [
  {
    label: "I", title: "비효율적 방황", subtitle: "Inefficient Wandering",
    body: "AI가 최적화할수록, 느린 탐구와 실패를 보호하는 리더십. 돌아가는 길의 의미를 지키는 학교 문화.",
    pull: "최단 경로가 곧 학습은 아니다.",
  },
  {
    label: "II", title: "진짜 관계", subtitle: "Authentic Relationship",
    body: "기계가 모방할 수 있는 것은 관계의 형식이지, 이해받는 느낌이 아닙니다. 그 느낌을 중심으로 하는 학교.",
    pull: "이해받는 느낌은 대체되지 않는다.",
  },
  {
    label: "III", title: "의미 만들기", subtitle: "Sense-making",
    body: "지식을 넘어 자신의 서사를 재구성하는 배움. 인간은 의도적으로 잊고 다시 짓는 존재입니다.",
    pull: "기억보다 재구성이 인간을 만든다.",
  },
];

const CRISIS_6 = [
  { n: "28", t: "급식 사고", k: "보존식 확보", note: "즉시 급식 중단·분리 → 보존식·현장 보전" },
  { n: "29", t: "학교폭력", k: "전담기구", note: "즉시 보호·분리 → 전담기구 사안 조사" },
  { n: "30", t: "아동학대", k: "의심만으로 즉시 신고", danger: "보호자 선확인 절대 금지", note: "즉시 보호 → 즉시 신고 → 비유도적 면담" },
  { n: "31", t: "체험학습", k: "사전 위험성 평가", note: "사전 평가 → 역할 분담 → 사후 환류" },
  { n: "32", t: "교육활동 침해", k: "교육활동보호위원회", danger: "비공식 대응 금지", note: "즉시 보호 → 보호위 가동 → 2차 피해 방지" },
  { n: "33", t: "심리·정서 위기", k: "Wee 3단계 연계", note: "조기 발견 → 안전 확보 → 초기 대응팀" },
];

const SEJONG_TERMS = [
  { abbr: "정다움", title: "정밀진단·다중안전망·기초학력", body: "세 글자 안에 ‘정밀진단·다중안전망·기초학력’이 압축되어 있습니다. 19, 20, 21, 42에서 답변의 신뢰도를 가르는 한 단어.", tag: "기초학력" },
  { abbr: "모두이음", title: "복합 위기 학생 통합 지원 체계", body: "교육청과 지역사회를 잇는 통합 지원망. 19, 21, 25, 33 — 학생 한 명을 둘러싼 모든 자원을 호명하는 이름.", tag: "통합 지원" },
  { abbr: "AIEP", title: "AI 기반 개별 맞춤 학습 진단 플랫폼", body: "데이터로 보는 한 학생의 학습 지형도. 16, 18, 19, 20, 42, 43에서 답변의 구체성을 보장합니다.", tag: "플랫폼" },
  { abbr: "세종미래장학", title: "지원 중심의 수업 장학 체계", body: "‘평가’가 아닌 ‘지원’으로 전환된 장학. 09, 11, 22 — 교감의 역할이 ‘동반자’로 갱신되는 지점.", tag: "장학" },
];

const TICKER_MSGS = [
  "01 사회현상 → 수치 1개 + 교육 연결 키워드",
  "07 악성민원 ≠ 32 교권침해",
  "28 급식 = 보존식",
  "30 아동학대 = 즉시 신고 · 보호자 선확인 금지",
  "33 심리위기 = Wee 3단계",
  "36 휴직 · 37 휴가 · 38 겸직",
  "정다움 · 모두이음 · AIEP · 세종미래장학",
  "I 전체지도 → II 3키워드 → III 흐름 → IV 혼동주의",
];

// ---------- Helpers ----------
function useReveal() {
  const ref = useRef(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setSeen(true); io.disconnect(); }
    }, { threshold: 0.15 });
    io.observe(ref.current);
    return () => io.disconnect();
  }, []);
  return [ref, seen];
}

function Reveal({ children, delay = 0, className = "" }) {
  const [ref, seen] = useReveal();
  return (
    <div ref={ref} className={"reveal " + (seen ? "in " : "") + className} style={{ transitionDelay: delay + "ms" }}>
      {children}
    </div>
  );
}

// ---------- Sections ----------
function TopBar() {
  return (
    <div className="border-b rule above" style={{ background: "var(--paper)" }}>
      <div className="max-w-[1280px] mx-auto px-8 py-3 flex items-center justify-between text-[13px]">
        <div className="flex items-center gap-3">
          <span className="latin-display italic text-2xl font-black tracking-tight">Readdy</span>
          <span className="ticker">.ai · 교감 자격 심층면접 시리즈</span>
        </div>
        <div className="hidden md:flex items-center gap-6 small-cap">
          <a href="#problem" className="hover:opacity-60">문제</a>
          <a href="#system" className="hover:opacity-60">4단계 시스템</a>
          <a href="#values" className="hover:opacity-60">3가지 가치</a>
          <a href="#crisis" className="hover:opacity-60">위기 마스터</a>
          <a href="#sejong" className="hover:opacity-60">세종 사전</a>
        </div>
        <div className="flex items-center gap-3">
          <span className="chip">2026 · 세종</span>
          <span className="chip chip-solid">v.4</span>
        </div>
      </div>
    </div>
  );
}

function Hero() {
  return (
    <section className="above" data-screen-label="01 Hero">
      <div className="max-w-[1280px] mx-auto px-8 pt-14 pb-10">
        {/* meta row */}
        <div className="flex items-center justify-between mb-12">
          <div className="flex items-center gap-4">
            <span className="small-cap">No. 01—44</span>
            <span className="vline" style={{ height: 14 }}></span>
            <span className="small-cap">SEJONG VICE-PRINCIPAL · 2026</span>
          </div>
          <span className="stamp-box small-cap">MEMORIZATION FRAME</span>
        </div>

        <div className="grid grid-cols-12 gap-6 items-end">
          {/* big numerals */}
          <div className="col-span-12 lg:col-span-5">
            <Reveal>
              <div className="num-44 cinnabar leading-[0.85]" style={{ fontSize: "clamp(110px, 13vw, 220px)" }}>
                01<span className="ink">—</span>44
              </div>
              <div className="mt-2 small-cap accent">Forty-four cards. One frame.</div>
            </Reveal>
          </div>

          {/* headline */}
          <div className="col-span-12 lg:col-span-7">
            <Reveal delay={150}>
              <h1 className="display text-[clamp(36px,4.4vw,68px)] leading-[1.05]">
                방대한 자료의 길을<br/>
                <span className="cinnabar">단 4단계</span>로 정리합니다.
              </h1>
              <p className="mt-7 text-[19px] leading-[1.7]" style={{ color: "var(--ink-2)" }}>
                세종시 교감 자격 심층면접의 <span className="underline-mark">44개 주제</span>—
                선택형부터 위기·안전, 인사·복무, 교육 혁신까지.
                Readdy.ai가 제공하는 <strong>핵심 암기 가이드</strong>로
                흩어진 자료를 하나의 구조화된 뼈대 위에 다시 세웁니다.
                면접의 합격선이 선명해지는 순간.
              </p>
            </Reveal>
          </div>
        </div>

        {/* CTA row */}
        <Reveal delay={300}>
          <div className="mt-14 flex flex-wrap items-center gap-4">
            <a href="#system" className="btn-primary text-[17px]">
              <span>지금 바로 4단계 암기틀 시작하기</span>
              <span className="arrow">→</span>
            </a>
            <a href="#problem" className="btn-ghost">전체 지도 먼저 보기</a>
            <div className="ml-auto small-cap" style={{ color: "var(--muted)" }}>
              Updated · 2026.05.08 · 교양 20 + 교직 24
            </div>
          </div>
        </Reveal>
      </div>
      {/* divider with edition */}
      <div className="border-t rule">
        <div className="max-w-[1280px] mx-auto px-8 py-3 flex items-center justify-between small-cap" style={{ color: "var(--muted)" }}>
          <span>Edition · 교감자격연수 / 심층면접</span>
          <span>I · II · III · IV</span>
          <span>Readdy.ai Memorization Series</span>
        </div>
      </div>
    </section>
  );
}

function Ticker() {
  return (
    <div className="marquee-wrap above">
      <div className="marquee">
        {[...TICKER_MSGS, ...TICKER_MSGS, ...TICKER_MSGS].map((m, i) => (
          <span key={i}>※ {m}</span>
        ))}
      </div>
    </div>
  );
}

function Problem() {
  return (
    <section id="problem" className="above py-24" data-screen-label="02 Problem">
      <div className="max-w-[1280px] mx-auto px-8">
        <div className="grid grid-cols-12 gap-10">
          <div className="col-span-12 lg:col-span-4">
            <Reveal>
              <div className="small-cap mb-4">CHAPTER · I</div>
              <h2 className="display text-[clamp(34px,3.6vw,54px)] leading-[1.1]">
                교양부터 교직까지,<br/>
                <span className="cinnabar">44개의 주제</span>를<br/>
                어떻게 다 외울까.
              </h2>
              <p className="mt-6 text-[17px] leading-[1.75]" style={{ color: "var(--ink-2)" }}>
                선택형·공동체·갈등·AI·디지털 등 <strong>교양 20개</strong>,
                세종 정책·위기·안전·교육 혁신 등 <strong>교직 24개</strong>.
                면접장에서 당황하지 않으려면 단순 암기가 아닌
                <span className="underline-mark"> 구조화된 뼈대</span>가 필요합니다.
              </p>
              <div className="mt-8 flex gap-3">
                <span className="chip"><span className="badge-44 mr-1" style={{background:'var(--ink)'}}>20</span> 교양</span>
                <span className="chip"><span className="badge-44 mr-1">24</span> 교직</span>
              </div>
            </Reveal>
          </div>

          <div className="col-span-12 lg:col-span-8">
            <Reveal delay={150}>
              <div className="ticket p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="small-cap">전체 지도 · 44 cards</span>
                  <span className="small-cap" style={{ color: "var(--muted)" }}>색칠된 셀 = 가장 자주 헷갈리는 영역</span>
                </div>
                <div className="grid-44">
                  {TOPICS_44.map(c => (
                    <div key={c.n} className="cell-44" data-group={c.g} title={`${c.n} ${c.t} · ${c.g}`}>
                      <div className="num">{c.n}</div>
                      <div className="text-[8px] opacity-70 px-1 text-center" style={{ lineHeight: 1.05 }}>{c.g.slice(0,4)}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-5 flex flex-wrap gap-x-5 gap-y-2 text-[12px]" style={{ color: "var(--muted)" }}>
                  <span className="flex items-center gap-2"><span className="inline-block w-3 h-3" style={{background:'rgba(181,58,44,0.08)', border:'1px solid var(--accent-2)'}}></span>위기·안전 · 28–33</span>
                  <span className="flex items-center gap-2"><span className="inline-block w-3 h-3" style={{background:'rgba(31,58,138,0.08)', border:'1px solid var(--accent)'}}></span>세종 정책 · 21–24</span>
                  <span className="flex items-center gap-2"><span className="inline-block w-3 h-3" style={{border:'1px solid var(--accent-2)'}}></span>선택형 · 01–03</span>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

function System() {
  const [active, setActive] = useState(0);
  const step = STEPS[active];
  return (
    <section id="system" className="above border-t border-b rule py-28" style={{ background: "var(--paper-2)" }} data-screen-label="03 4-step System">
      <div className="max-w-[1280px] mx-auto px-8">
        <Reveal>
          <div className="flex items-end justify-between mb-12 flex-wrap gap-6">
            <div>
              <div className="small-cap mb-3">CHAPTER · II  ·  THE CORE</div>
              <h2 className="display text-[clamp(36px,4vw,60px)] leading-[1.05]">
                Readdy.ai만의 검증된<br/>
                <span className="cinnabar">4단계 심층면접 암기 솔루션</span>
              </h2>
            </div>
            <div className="pull-quote text-[19px] max-w-md italic" style={{ color: "var(--ink-2)" }}>
              "외운다"가 아니라<br/>"답변의 좌표를 잡는다."
            </div>
          </div>
        </Reveal>

        <div className="grid grid-cols-12 gap-8">
          {/* Step list */}
          <div className="col-span-12 lg:col-span-5">
            <div className="flex flex-col gap-3">
              {STEPS.map((s, i) => (
                <button
                  key={s.n}
                  className="tab-btn flex items-center gap-5"
                  data-active={i === active}
                  onClick={() => setActive(i)}
                >
                  <span className="step-num text-3xl" style={{ color: i === active ? "var(--paper)" : "var(--accent-2)" }}>{s.n}</span>
                  <span className="flex flex-col items-start">
                    <span className="display text-[22px]">{s.k}</span>
                    <span className="small-cap mt-1" style={{ opacity: 0.7 }}>{s.sub}</span>
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Step detail */}
          <div className="col-span-12 lg:col-span-7">
            <div className="ticket p-8 min-h-[420px]">
              <div className="flex items-baseline justify-between border-b rule pb-4">
                <div className="flex items-baseline gap-5">
                  <span className="step-num text-[64px] leading-none">{step.n}</span>
                  <div>
                    <div className="display text-[28px] leading-tight">{step.k}</div>
                    <div className="small-cap mt-1" style={{ color: "var(--muted)" }}>{step.sub} · STEP {active + 1} OF 4</div>
                  </div>
                </div>
                <span className="chip">{active + 1} / 4</span>
              </div>
              <p className="mt-6 text-[18px] leading-[1.8]">{step.body}</p>

              <div className="mt-6 small-cap mb-2" style={{ color: "var(--muted)" }}>이 단계의 예시</div>
              <div className="flex flex-wrap">
                {step.chips.map((c, i) => (
                  <span key={i} className={"keyword-pill " + (i === 0 ? "solid" : "")}>{c}</span>
                ))}
              </div>

              {active === 3 && (
                <div className="mt-7 danger-block p-5 flex gap-4">
                  <span className="latin-display italic text-3xl">!</span>
                  <div>
                    <div className="small-cap mb-1" style={{ opacity: .8 }}>예시 · 혼동 주의</div>
                    <div className="text-[16px] leading-[1.7]">
                      <strong>07 악성·반복 민원</strong> = ‘창구 일원화’ &nbsp;<span style={{opacity:.6}}>vs</span>&nbsp;
                      <strong>32 교육활동 침해</strong> = ‘교육활동보호위원회 가동’.
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* progress */}
        <div className="mt-10 grid grid-cols-4 gap-3">
          {STEPS.map((s, i) => (
            <div key={i} className="h-1" style={{ background: i <= active ? "var(--accent-2)" : "rgba(26,26,31,0.15)" }}></div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ValuesThree() {
  const [active, setActive] = useState(0);
  const v = VALUES_3[active];
  return (
    <section id="values" className="above py-28" data-screen-label="04 3 Values">
      <div className="max-w-[1280px] mx-auto px-8">
        <div className="grid grid-cols-12 gap-10">
          <div className="col-span-12 lg:col-span-4">
            <Reveal>
              <div className="small-cap mb-3">CHAPTER · III  ·  PHILOSOPHY</div>
              <h2 className="display text-[clamp(32px,3.4vw,50px)] leading-[1.1]">
                면접관을 사로잡는<br/>
                <span className="accent">‘AI 시대 교감의<br/>3가지 불변 가치’</span>
              </h2>
              <p className="mt-6 text-[16px] leading-[1.75]" style={{ color: "var(--ink-2)" }}>
                단순한 행정 처리 방안을 넘어, 교육의 본질을 짚어냅니다.
                <span className="hand"> 제프 베조스</span>의 “변하지 않을 것에 집중” 프레임을 차용한
                답변 구조로, 다음 세 가지 불변 가치를 제시해 보세요.
              </p>
              <div className="mt-7 grid grid-cols-3 gap-2">
                {VALUES_3.map((x, i) => (
                  <button key={i} onClick={() => setActive(i)} className="tab-btn p-3" data-active={i === active}>
                    <div className="step-num text-xl" style={{ color: i === active ? "var(--paper)" : "var(--accent)" }}>{x.label}</div>
                    <div className="text-[14px] mt-1">{x.title}</div>
                  </button>
                ))}
              </div>
            </Reveal>
          </div>

          <div className="col-span-12 lg:col-span-8">
            <Reveal delay={120}>
              <div className="ticket-blue p-10 grid-paper relative overflow-hidden">
                <div className="absolute top-6 right-6 stamp-box" style={{ borderColor: "var(--accent)", color: "var(--accent)", transform: "rotate(2deg)" }}>JEFF BEZOS · FRAMING</div>
                <div className="num-44 text-[180px] leading-[0.8] accent opacity-90">{v.label}</div>
                <div className="display text-[40px] mt-2 leading-tight">{v.title}</div>
                <div className="small-cap mt-2" style={{ color: "var(--muted)" }}>{v.subtitle}</div>
                <p className="mt-7 text-[20px] leading-[1.75] max-w-[55ch]">{v.body}</p>
                <div className="mt-10 border-t rule pt-6 flex items-start gap-4">
                  <span className="latin-display italic text-5xl accent leading-none">"</span>
                  <p className="pull-quote text-[26px] leading-[1.3] max-w-[40ch]">{v.pull}</p>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-3">
                {VALUES_3.map((x, i) => (
                  <div key={i} className="text-[12px]" style={{ color: i === active ? "var(--ink)" : "var(--muted)" }}>
                    <span className="step-num mr-2">{x.label}</span>{x.title}
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

function CrisisMaster() {
  const [hoverIdx, setHoverIdx] = useState(2); // 30 default
  const item = CRISIS_6[hoverIdx];
  return (
    <section id="crisis" className="above border-t rule py-28" style={{ background: "var(--ink)", color: "var(--paper)" }} data-screen-label="05 Crisis Master">
      <div className="max-w-[1280px] mx-auto px-8">
        <div className="grid grid-cols-12 gap-10 items-start">
          <div className="col-span-12 lg:col-span-5">
            <Reveal>
              <div className="small-cap mb-3" style={{ color: "rgba(244,239,230,0.6)" }}>CHAPTER · IV  ·  MASTER KEY</div>
              <h2 className="display text-[clamp(32px,3.4vw,52px)] leading-[1.05]" style={{ color: "var(--paper)" }}>
                위기·안전 <span className="num-marker">28—33</span>,<br/>
                <span style={{ color: "#eab86a" }}>공통 흐름 하나</span>로 끝냅니다.
              </h2>
              <p className="mt-6 text-[17px] leading-[1.8]" style={{ color: "rgba(244,239,230,0.8)" }}>
                급식 사고·학교폭력·아동학대·체험학습·교권 침해·심리 위기 — 어떤 위기 문항이 출제되어도
                흔들리지 않는 마스터키 구조를 제공합니다. 문항별 결정적 키워드만 대입하면 답변이 완성됩니다.
              </p>
              {/* formula */}
              <div className="mt-8 ticket p-5" style={{ background: "transparent", borderColor: "rgba(244,239,230,0.4)", boxShadow: "4px 4px 0 0 rgba(234,184,106,0.6)" }}>
                <div className="small-cap mb-3" style={{ color: "rgba(244,239,230,0.6)" }}>답변 공식 · MASTER FORMULA</div>
                <div className="display text-[20px] leading-[1.6]" style={{ color: "var(--paper)" }}>
                  즉시 보호 <span style={{color:'#eab86a'}}>→</span> 절차 준수·기록 <span style={{color:'#eab86a'}}>→</span> 기관 연계·보고 <span style={{color:'#eab86a'}}>→</span> 피해자 지원 <span style={{color:'#eab86a'}}>→</span> 재발 방지
                </div>
              </div>
            </Reveal>
          </div>

          <div className="col-span-12 lg:col-span-7">
            <Reveal delay={120}>
              <div className="grid grid-cols-2 gap-3">
                {CRISIS_6.map((c, i) => (
                  <div
                    key={c.n}
                    onMouseEnter={() => setHoverIdx(i)}
                    onClick={() => setHoverIdx(i)}
                    className="p-5 cursor-pointer transition-all"
                    style={{
                      border: "1px solid rgba(244,239,230,0.3)",
                      background: i === hoverIdx ? "var(--accent-2)" : "transparent",
                      transform: i === hoverIdx ? "translate(-2px,-2px)" : "none",
                      boxShadow: i === hoverIdx ? "4px 4px 0 0 #eab86a" : "none",
                    }}
                  >
                    <div className="flex items-baseline justify-between">
                      <span className="num-marker text-[34px]" style={{ color: i === hoverIdx ? "var(--paper)" : "#eab86a" }}>{c.n}</span>
                      {c.danger && <span className="small-cap" style={{ color: "#eab86a" }}>!</span>}
                    </div>
                    <div className="display text-[20px] mt-1">{c.t}</div>
                    <div className="mt-3 text-[14px]" style={{ color: i === hoverIdx ? "rgba(244,239,230,0.95)" : "rgba(244,239,230,0.7)" }}>
                      <span className="small-cap" style={{ color: i === hoverIdx ? "#eab86a" : "rgba(244,239,230,0.55)" }}>한 단어</span>
                      <div className="mt-1 text-[16px]">{c.k}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* danger callout */}
              {item.danger && (
                <div className="mt-6 p-5 flex items-start gap-5" style={{ background: "#eab86a", color: "var(--ink)" }}>
                  <span className="latin-display italic font-black text-5xl leading-none">!</span>
                  <div>
                    <div className="small-cap mb-1">{item.n} · 절대 금지</div>
                    <div className="display text-[22px]">{item.danger}</div>
                    <div className="mt-1 text-[14px]" style={{ color: "var(--ink-2)" }}>{item.note}</div>
                  </div>
                </div>
              )}
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

function SejongDictionary() {
  return (
    <section id="sejong" className="above py-28" data-screen-label="06 Sejong Dictionary">
      <div className="max-w-[1280px] mx-auto px-8">
        <Reveal>
          <div className="flex items-end justify-between flex-wrap gap-6 mb-12">
            <div>
              <div className="small-cap mb-3">CHAPTER · V  ·  LOCAL VOCABULARY</div>
              <h2 className="display text-[clamp(34px,3.8vw,56px)] leading-[1.05]">
                세종시 교감이라면<br/>
                반드시 알아야 할 <span className="cinnabar">‘로컬 언어’</span>
              </h2>
            </div>
            <div className="max-w-md text-[16px] leading-[1.75]" style={{ color: "var(--ink-2)" }}>
              세종시 교육 정책과 직결되는 핵심 고유명사를 완벽 정리했습니다.
              답변의 전문성을 한 차원 높여줍니다.
            </div>
          </div>
        </Reveal>

        <div className="grid grid-cols-12 gap-6">
          {SEJONG_TERMS.map((term, i) => (
            <Reveal key={term.abbr} delay={i * 80} className="col-span-12 md:col-span-6 lg:col-span-3">
              <div className="ticket p-6 h-full flex flex-col">
                <div className="flex items-start justify-between">
                  <span className="small-cap" style={{ color: "var(--muted)" }}>NO. {String(i+1).padStart(2,'0')}</span>
                  <span className="chip">{term.tag}</span>
                </div>
                <div className="display text-[34px] mt-4 cinnabar leading-tight">{term.abbr}</div>
                <div className="small-cap mt-2" style={{ color: "var(--ink-2)" }}>{term.title}</div>
                <p className="mt-5 text-[14px] leading-[1.7]" style={{ color: "var(--ink-2)" }}>{term.body}</p>
                <div className="mt-auto pt-5 border-t rule small-cap" style={{ color: "var(--muted)" }}>
                  PRONOUNCE · {term.abbr.toUpperCase()}
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section className="above border-t rule py-28" style={{ background: "var(--paper-2)" }} data-screen-label="07 Final CTA">
      <div className="max-w-[1280px] mx-auto px-8">
        <div className="grid grid-cols-12 gap-10 items-end">
          <div className="col-span-12 lg:col-span-8">
            <Reveal>
              <div className="small-cap mb-3">EPILOGUE</div>
              <h2 className="display text-[clamp(40px,5vw,76px)] leading-[1.0]">
                체계적인 전체 지도부터<br/>
                <span className="cinnabar">혼동하기 쉬운 문항 비교</span><br/>
                총정리까지.
              </h2>
              <p className="mt-7 text-[18px] leading-[1.75] max-w-[60ch]" style={{ color: "var(--ink-2)" }}>
                Readdy.ai의 암기틀과 함께라면, 방대한 심층면접 준비도
                <span className="underline-mark"> 효율적인 여정</span>이 됩니다.
              </p>
            </Reveal>
          </div>
          <div className="col-span-12 lg:col-span-4 flex flex-col gap-4">
            <Reveal delay={150}>
              <a href="#" className="btn-primary text-[18px] justify-between w-full">
                <span>핵심 암기 가이드<br/>전체 보기 및 다운로드</span>
                <span className="arrow text-2xl">↓</span>
              </a>
              <div className="mt-3 flex items-center gap-3 text-[13px]" style={{ color: "var(--muted)" }}>
                <span className="seal">암</span>
                <div>
                  <div className="display text-[16px] ink">PDF · Markdown · Notion</div>
                  <div>총 44개 카드 · 13.6KB · 즉시 다운로드</div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>

        {/* foot */}
        <div className="mt-20 border-t rule pt-6 flex flex-wrap items-center justify-between gap-4 small-cap" style={{ color: "var(--muted)" }}>
          <span><span className="latin-display italic">Readdy</span>.ai · Memorization Series · 2026</span>
          <span>교감자격연수 · 심층면접 · v.4</span>
          <span>Made for 세종 · with rigor</span>
        </div>
      </div>
    </section>
  );
}

// ---------- Tweaks ----------
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "ivory_blue",
  "accent": "cinnabar",
  "displayFont": "noto_serif"
}/*EDITMODE-END*/;

function TweaksPanelMount() {
  const TweaksPanel = window.TweaksPanel;
  const useTweaks = window.useTweaks;
  const TweakSection = window.TweakSection;
  const TweakRadio = window.TweakRadio;
  const TweakColor = window.TweakColor;
  if (!TweaksPanel) return null;

  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useEffect(() => {
    const root = document.documentElement.style;
    const palettes = {
      ivory_blue: { paper: "#f4efe6", paper2: "#ebe4d6", ink: "#1a1a1f" },
      bone_dark:  { paper: "#e9e2d2", paper2: "#ddd4be", ink: "#15151a" },
      paper_warm: { paper: "#f7f1e3", paper2: "#efe6d0", ink: "#221a14" },
    };
    const accents = {
      cinnabar: { a: "#1f3a8a", a2: "#b53a2c" },
      ink_only: { a: "#1a1a1f", a2: "#1a1a1f" },
      ocean:    { a: "#0e4f6f", a2: "#a23a2e" },
    };
    const p = palettes[t.palette] || palettes.ivory_blue;
    const a = accents[t.accent] || accents.cinnabar;
    root.setProperty("--paper", p.paper);
    root.setProperty("--paper-2", p.paper2);
    root.setProperty("--ink", p.ink);
    root.setProperty("--ink-2", p.ink);
    root.setProperty("--accent", a.a);
    root.setProperty("--accent-2", a.a2);
    document.body.style.fontFamily = t.displayFont === "myeongjo"
      ? "'Nanum Myeongjo', 'Noto Serif KR', serif"
      : "'Noto Serif KR', 'Nanum Myeongjo', serif";
  }, [t]);

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection title="Palette">
        <TweakRadio value={t.palette} onChange={v => setTweak("palette", v)}
          options={[
            { value: "ivory_blue", label: "Ivory" },
            { value: "bone_dark", label: "Bone" },
            { value: "paper_warm", label: "Warm" },
          ]} />
      </TweakSection>
      <TweakSection title="Accent">
        <TweakRadio value={t.accent} onChange={v => setTweak("accent", v)}
          options={[
            { value: "cinnabar", label: "Cinnabar" },
            { value: "ink_only", label: "Ink" },
            { value: "ocean",    label: "Ocean" },
          ]} />
      </TweakSection>
      <TweakSection title="Display Font">
        <TweakRadio value={t.displayFont} onChange={v => setTweak("displayFont", v)}
          options={[
            { value: "noto_serif", label: "Noto Serif" },
            { value: "myeongjo",   label: "Nanum Myeongjo" },
          ]} />
      </TweakSection>
    </TweaksPanel>
  );
}

function App() {
  return (
    <>
      <TopBar />
      <main>
        <Hero />
        <Ticker />
        <Problem />
        <System />
        <ValuesThree />
        <CrisisMaster />
        <SejongDictionary />
        <FinalCTA />
      </main>
      <TweaksPanelMount />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
